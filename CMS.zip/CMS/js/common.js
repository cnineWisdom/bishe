// var mainurl = 'http://chxz2018.iego.net/bishe/CI/index.php/Web/';
var mainurl = 'http://localhost:8080/bishe/CI/index.php/Web/';
function ajax(url,data,fn){
    $.ajax({
        url:mainurl+url,
        data:data,
        type:'post',
        async:false,
        dataType:'json',
        success:fn
    })
}

function getUrlParam(name)
{
var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)"); //构造一个含有目标参数的正则表达式对象
var r = window.location.search.substr(1).match(reg);  //匹配目标参数
if (r!=null) return unescape(r[2]); return null; //返回参数值
} 
function timestampToTime(timestamp) {
    var date = new Date(timestamp * 1000);//时间戳为10位需*1000，时间戳为13位的话不需乘1000
    Y = date.getFullYear() + '-';
    M = (date.getMonth()+1 < 10 ? '0'+(date.getMonth()+1) : date.getMonth()+1) + '-';
    D = date.getDate() + ' ';
    h = date.getHours() + ':';
    m = date.getMinutes() + ':';
    s = date.getSeconds();
    return Y+M+D+h+m+s;
}